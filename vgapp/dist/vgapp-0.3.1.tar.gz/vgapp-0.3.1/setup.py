# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['vgapp']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['vgapp = vgapp:trade.buy']}

setup_kwargs = {
    'name': 'vgapp',
    'version': '0.3.1',
    'description': '',
    'long_description': None,
    'author': 'John Gosset',
    'author_email': 'john@gossetx.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
