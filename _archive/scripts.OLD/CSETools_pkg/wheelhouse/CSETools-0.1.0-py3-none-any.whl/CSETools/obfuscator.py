def obf():
    print('OBFUSCATING')
