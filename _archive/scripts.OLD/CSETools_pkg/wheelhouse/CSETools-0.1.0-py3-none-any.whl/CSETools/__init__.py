from CSETools.Obfuscator import blackout
import CSETools.Scrutinizer.listen

nombre = "Juan"

def why_is_this_here():
    print("I have no idea...")
