def scrutinize():
    print('SCRUTINIZING!')
