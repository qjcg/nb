#!/usr/bin/env python3

def load_devrandom():
    with open('/dev/urandom', 'br') as f:
        f.read(1024000)

for _ in range(10):
    print('Loading 1024000 bytes from /dev/urandom')
    load_devrandom()
