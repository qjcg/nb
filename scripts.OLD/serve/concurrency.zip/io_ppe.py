#!/usr/bin/env python3
import concurrent.futures as cf

# Retrieve a single page and report the url and contents
def load_devrandom():
    with open('/dev/urandom', 'br') as f:
        f.read(10240000)

# We can use a with statement to ensure threads are cleaned up promptly
with cf.ProcessPoolExecutor() as executor:
    # Start the load operations and mark each future with its URL
    jobs = []
    for _ in range(10):
        job = executor.submit(load_devrandom)
        jobs.append(job)

    for future in cf.as_completed(jobs):
        print('Loaded 10240000 bytes from /dev/urandom')
        future.result()
